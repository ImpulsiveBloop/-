┌─────────────────────────────────────────────┐
│     Vader's CTM Programmer Bricks Pack      │
└─────────────────────────────────────────────┘

┌──────────┬─────────────────────────┬────────┐
│          │Resource Pack Created By:│        │
├──────────┴─────────────────────────┴────────┤
│                  Vaderman24                 │
└─────────────────────────────────────────────┘

┌──────────┬─────────────────────────┬────────┐
│          │Official Project Sources:│        │
├──────────┴─────────────────────────┴────────┤
│Curse Forge:                                 └───────────────────────────────────────┐ 
│https://www.curseforge.com/minecraft/texture-packs/vaders-ctm-programmer-bricks-pack │
├─────────────────────────────────────────────┬───────────────────────────────────────┘
│Modrinth:                                    │
│http://modrinth.com/user/Vaderman24          │
├─────────────────────────────────────────────┤
│Planet Minecraft:                            └─────────────────────────────────────────────────────────────────┐
│https://www.planetminecraft.com/texture-pack/16x16-vader-s-dirty-programmer-bricks-pack-programmer-art-add-on/ │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

┌───────────┬──────────────────────┬──────────┐
│           │Resource Pack Version:│          │
├───────────┴──────────────────────┴──────────┤
│                    1.0.0                    │
├────────┬────────────────────────────┬───────┤
│        │For Minecraft Java Editions:│       │
├────────┴────────────────────────────┴───────┤
│                1.7.2 - 1.20.6               │
│                                             │
│  Use with the Programmer Art Resource Pack  │
│  enabled below this pack for best results   │
└─────────────────────────────────────────────┘ 

┌──────────┬──────────────────────┬───────────┐
│          │Texture Contributions:│           │
├──────────┴──────────────────────┴───────────┤
│               Vaderman24 - 8                │
└─────────────────────────────────────────────┘

┌────────────┬───────────────────┬────────────┐
│            │   About The Pack  │            │
├────────────┴───────────────────┴────────────┤
│This pack adds 8 randomized textures for     │
│bricks to the game. It works by using        │
│Optifine's CTM (Connected Textures Mod)      │
│feature using the random method to create    │
│random block varients.                       │
│                                             │                             
│I hope to maintain this pack at my own pace  │
│and vision. So please be patient with any    │
│and all updates.                             │                           
└─────────────────────────────────────────────┘

┌────────────┬──────────────────┬─────────────┐
│            │   Asset Usage    │             │
├────────────┴──────────────────┴─────────────┤
│You may freely use any file,                 │
│license structure, page organization         │
│categories, or thread assets, found in this  │
│project for your own projects & purposes     │
│without asking me.                           │
|                                             │
|All I ask is that you give credit with a     │
|link to this projects page, and follow the   │
|CC BY-NC-SA 4.0 license guidelines.          │
│                                             │
│Please do not reupload this project elsewhere│
│without your own changes and project name.   │
└─────────────────────────────────────────────┘

┌───────────┬──────────────────────┬──────────┐
│           │    Credit Examples:  │          │
├───────────┴──────────────────────┴──────────┤
│     ◄▪◼▪◼▪◼▪◼▪|Start Sentence|▪◼▪◼▪◼▪◼▪►    │
│"(anything_you_want.exe)"                    │
│                                             │
│"Brick Textures are from [Insert End]"       │
│                                             │
│"Textures Used - [Insert End]"               │
│                                             │
│"This project uses assets from [Insert End]" │
├─────────────────────────────────────────────┤
│      ◄▪◼▪◼▪◼▪◼▪|End Sentence|▪◼▪◼▪◼▪◼▪►     └───┐
│Vader's CTM Programmer Bricks Pack by Vaderman24.│
├─────────────────────────────────────────────┬───┘
│    ◄▪◼▪◼▪◼▪◼▪|Example Sentence|▪◼▪◼▪◼▪◼▪►   └───────────────────────────────────┐
│"This project uses assets from Vader's CTM Programmer Bricks Pack by Vaderman24."│
├─────────────────────────────────────────────┬───────────────────────────────────┘
│ ◄▪◼▪◼▪◼▪|New Project Name Examples|▪◼▪◼▪◼▪► │
│"(anything_you_want.exe)"                    │
│                                             └────┐
│"[Your Name Here]'s Addon for [This Project Name]"└────────────────────────────────────────────────────────┐
│Example: https://www.curseforge.com/minecraft/texture-packs/addon-for-vaders-stacked-programmer-items-pack │
│                                                 ┌─────────────────────────────────────────────────────────┘
│"[Your Name Here]'s Dirty Programmer Bricks Pack"└────────────────────────────────┐
│Example: https://www.curseforge.com/minecraft/texture-packs/dashers-stacked-items │
└──────────────────────────────────────────────────────────────────────────────────┘

┌────────────┬──────────────────┬─────────────┐
│            │    Disclaimer    │             │
├────────────┴──────────────────┴─────────────┤
│Both at the time of creating this pack and   │
│of now, I do not consider myself to have any │
│kind of professional art skills. Everything  │
│about this and many of my other projects     │
│were originally intended for personal use and│ 
│are the result of many hours of random       │  
│experimentation to see what kinds of things  │
│I can create. Although I try to maintain a   │
│certain level of quality whenever possible,  │
│try to remember. Do it for the fun of it,    │
│mistakes happen, not everything has to       │
│be perfect, and that's okay.                 │               
│					                          │
│Thank you for your time and I hope you enjoy │
│the pack!                                    │
└─────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│©2024. This project is openly licensed via CC BY-NC-SA 4.0│
│https://creativecommons.org/licenses/by-nc-sa/4.0/ ┌──────┘
└───────────────────────────────────────────────────┘